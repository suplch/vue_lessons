<template>
	<div>
		我是navbar--<slot></slot>
	</div>
</template>

<script type="text/javascript">
export default {
  data () {
    return {

    }
  }
}
</script>
